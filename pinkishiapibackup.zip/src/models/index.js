const Role = require("./roleModel");
const Menu = require("./menuModel");
const RoleMenu = require("./roleMenuModel");

/* =====================
   MANY TO MANY
===================== */
Role.belongsToMany(Menu, {
  through: RoleMenu,
  foreignKey: "roleId",
  otherKey: "menuId"
});

Menu.belongsToMany(Role, {
  through: RoleMenu,
  foreignKey: "menuId",
  otherKey: "roleId"
});

/* =====================
   DIRECT (optional)
===================== */
Menu.hasMany(RoleMenu, { foreignKey: "menuId" });
RoleMenu.belongsTo(Menu, { foreignKey: "menuId" });

Role.hasMany(RoleMenu, { foreignKey: "roleId" });
RoleMenu.belongsTo(Role, { foreignKey: "roleId" });

module.exports = {
  Role,
  Menu,
  RoleMenu
};
